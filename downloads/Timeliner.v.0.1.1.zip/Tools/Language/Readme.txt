Translation readme
------------------
To prepare a translation:
- Translate English.lng and test it. Do not localize special chars:
  \n \r \t %s %d.
- Include information about you in [About] section.
- Mask email by replacing '@' with '(at)'.
- Name your file with ASCII characters only.

Versions history
----------------
4.0 Cap 278 140, Msg 203-204 129
4.1 Msg 257 Cap 805-810
4.2 Cap -200-218, [Nav]
4.3 Nav 218 206 Msg -310-315 108 Cap 349
4.4 Cap -387-8 360-1 Msg -128 130 155-156
5.2 nav 207 219-221 cap 362
5.3 Msg 310-2 cap 187 279
5.4 Msg 313-5 Cap 811-2
5.4.3 Msg 111 Cap 222
5.4.7 Cap 339 263 Msg 316
5.5.0 msg 113-114
5.5.2 cap 813 436 139 417 -277 120 msg 317


6.0: Cap 900-.. 138 174 363 408 -166 -173 -220-223
 700-708 msg 320-323
6.1: cap 157-8, 226-7, 235-245
  922-930
6.2
  cap 175 921 929 188-9

6.2.5
 cap 364-6
6.2.6
 cap 387
6.3.0
 cap 814-20 409 354-5
 [About] section name not needed
6.4.5
 cap 821-2 228-9
6.4.5.1
 cap 313,314
6.5.0
 cap 356 908 830-839
