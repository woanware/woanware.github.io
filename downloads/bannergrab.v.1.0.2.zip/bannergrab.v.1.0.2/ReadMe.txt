

  bannergrab

  Copyright (c) 2007 woanware
  Developed by Mark Woan (markwoan[at]hotmail.com)

  ---------------------------------------------------------------------------

  The majority of banner grabbing tools cannot work with SSL, bannergrab 
  supports SSL and can perform banner grabbing on SSL-based services...
  
  
  Features
  --------
  - Console
  - SSL support
  - Variable output e.g. text, hex and text with hex
  
  
  Disclaimer
  ----------
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.

  THIS APPLICATION IS ONLY TO BE USED ON WEBSITES/APPLICATIONS THAT EITHER YOU
  OWN OR HAVE EXPRESS WRITTEN PERMISSION TO TEST.

  BY USING THIS SOFTWARE YOU ARE AGREEING TO THE CONDITIONS AND TERMS EXPRESSED 
  ABOVE.


  System Requirements
  -------------------

  - Windows 2000, Windows XP, Windows 2003 Server (Might work on others?)
  - Microsoft .NET Framework v2


  Contact
  -------
  If you have any problems, then email me at markwoan[at]hotmail.com and I will
  try and sort them asap. 


  ---------------------------------------------------------------------------

  woanware
  http://www.woany.co.uk/