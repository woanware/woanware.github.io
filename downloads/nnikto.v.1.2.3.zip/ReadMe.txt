

  nnikto

  Copyright (c) 2011 woanware
  Developed by Mark Woan (markwoan[at]gmail.com)

  ---------------------------------------------------------------------------

  A console app to perform forced browsing checks against a web server...

	
  About
  -----
  It is heavily based apon nikto (cirt) and wikto (SensePost). It contains 
  semi-intelligent techniques to prevent false positives...
		

  Features
  --------
  - Tolerance algorithm level modification (-a)
  - Thread pooled, so its quicker than nikto
  - SSL support (-s)
  - Configurable Port (wow) (-p)
  - Semi-intelligent techniques to determine false positives
  - The responses from items located can be saved for checking later, so you don�t 
    manually have to go to the site and check :-) (-l)
  - Add cgi directories (-c), use a pipe (|) to separate each like "-d bob|chicken|fred"
  - Doesn't hog the CPU like wikto
  - Supports Basic Auth, NTLM and Negotiate
  - Supports cookies


  Disclaimer
  -------------------
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.

  THIS APPLICATION IS ONLY TO BE USED ON WEBSITES/APPLICATIONS THAT EITHER YOU
  OWN OR HAVE EXPRESS WRITTEN PERMISSION TO TEST.

  BY USING THIS SOFTWARE YOU ARE AGREEING TO THE CONDITIONS AND TERMS EXPRESSED 
  ABOVE.


  System Requirements
  -------------------
  
  - Windows 2000, Windows XP, Windows 2003 Server (Might work on others?)
  - Microsoft .NET Framework v2
	

  Contact
  -------
  If you have any problems, then email me at markwoan[at]hotmail.com and I will
  try and sort them asap. 

	
  Credits
  -------
  nikto: http://www.cirt.net/code/nikto.shtml
  wikto: http://www.sensepost.com/research/wikto/
  CSV Reader: http://www.codeproject.com/cs/database/CsvReader.asp
	
	
  ---------------------------------------------------------------------------

  woanware
  http://www.woany.co.uk/

	



