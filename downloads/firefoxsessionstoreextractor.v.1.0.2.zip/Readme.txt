

  firefoxsessionstoreextractor

  Copyright (c) 2010 woanware
  Developed by Mark Woan (markwoan@gmail.com)

  ---------------------------------------------------------------------------

  
  About
  -----
  A console application to parse the FireFox sessionstore.js JSON files. The 
  idea came from the paper (Web Browser Session Restore Forensics ) written 
  by Harry Parsonage (see below).
  
  The sessionstore.js files are simply in JSON format and easily extracted. 
  The application simply displays the info in a easily presentation format and
  can also parse entire directories of the files.
  
  
  Links
  -----
  http://computerforensics.parsonage.co.uk/downloads/WebBrowserSessionRestoreForensics.pdf
  

  Disclaimer
  -------------------
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.

  BY USING THIS SOFTWARE YOU ARE AGREEING TO THE CONDITIONS AND TERMS EXPRESSED 
  ABOVE.
  
  IF YOU ARE USING THIS TO PROVIDE EVIDENCE FOR A COURT CASE THEN ENSURE THAT YOU 
  VALIDATE YOUR RESULTS.


  System Requirements
  -------------------

  - Windows XP, Windows 2003 Server, Vista, WIndows 7
  - Microsoft .NET Framework v3.5 or Mono v2+??


  ---------------------------------------------------------------------------

  woanware
  http://www.woanware.co.uk/

  



