
  verbcheck

  Copyright (c) 2010 woanware
  Developed by Mark Woan (markwoan[at]gmail.com)

  ---------------------------------------------------------------------------
  
  About
  -----
  Performs simple HTTP requests to validate the web servers supported HTTP 
  verbs...
    
  Features
  --------
  - Configurable port
  - HTTPS support
  - Logs to file
  - Configurable HTTP verb support via Checks.xml (located in app dir)
  - Authentication support e.g. Basic, NTLM etc
  
  Notes
  -----
  If a check has Body content then a "Content-Length" header is automatically
  defined and therefore a "Content-Length" header node does not have to added
  the "Checks.xml" file


  System Requirements
  -------------------
  - Microsoft .NET Framework v4

  Disclaimer
  -------------------
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.

  THIS APPLICATION IS ONLY TO BE USED ON WEBSITES/APPLICATIONS THAT EITHER YOU
  OWN OR HAVE EXPRESS WRITTEN PERMISSION TO TEST.

  BY USING THIS SOFTWARE YOU ARE AGREEING TO THE CONDITIONS AND TERMS EXPRESSED 
  ABOVE.

  ---------------------------------------------------------------------------

  woanware
  http://www.woanware.co.uk/