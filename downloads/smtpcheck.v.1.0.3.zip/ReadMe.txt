

  smtpcheck

  Copyright (c) 2007 woanware
  Developed by Mark Woan (markwoan[at]hotmail.com)

  ---------------------------------------------------------------------------

  A console app to test SMTP server configurations...

	
  About
  -----
  Just wanted to quickly automate SMTP VRFY, EXPN and relaying checks.
	
	
  Features
  --------
  - VRFY root
  - VRFY Administrator
  - VRFY chicken
  - VRFY admin
  - VRFY thisuserdoesntexist
  - EXPN root
  - EXPN Administrator
  - EXPN chicken
  - EXPN admin
  - EXPN thisuserdoesntexist
  - Relay check


  Disclaimer
  -------------------
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  
  THIS APPLICATION IS ONLY TO BE USED ON WEBSITES/APPLICATIONS THAT EITHER YOU
  OWN OR HAVE EXPRESS WRITTEN PERMISSION TO TEST.

  BY USING THIS SOFTWARE YOU ARE AGREEING TO THE CONDITIONS AND TERMS EXPRESSED 
  ABOVE.


  System Requirements
  -------------------

  - Windows 2000, Windows XP, Windows 2003 Server (Might work on others?)
  - Microsoft .NET Framework v1.1


  Contact
  -------
  If you have any problems, then email me at markwoan[at]hotmail.com and I will
  try and sort them asap. 


  ---------------------------------------------------------------------------

  woanware
  http://www.woany.co.uk/

	



