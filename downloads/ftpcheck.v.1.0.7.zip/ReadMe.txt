

  ftpcheck

  Copyright (c) 2012 woanware
  Developed by Mark Woan (markwoan[at]gmail.com)

  ---------------------------------------------------------------------------

  Got bored logging into FTP services checking for anonymous authentication and
  whether I can have write privileges etc, so ftpcheck does it.
  
  Features
  --------
  - Checks for anonymous authentication
  - Checks for write privileges
  - Attempts to retrieve the system details using the SYST command
  - Retrieves the directory listing when connected
  - Retrieves the current working directory using the PWD command
  - Attempts some user enumeration using the "~" directory name format
  - Attempts to retrieve the /etc/passwd file using path traversal
  - Attempts to retrieve the .rhosts file
  - Attempts to retrieve the boot.ini using path traversal

  Disclaimer
  ----------
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.

  THIS APPLICATION IS ONLY TO BE USED ON WEBSITES/APPLICATIONS THAT EITHER YOU
  OWN OR HAVE EXPRESS WRITTEN PERMISSION TO TEST.

  BY USING THIS SOFTWARE YOU ARE AGREEING TO THE CONDITIONS AND TERMS EXPRESSED 
  ABOVE.


  System Requirements
  -------------------
  - Microsoft .NET Framework v4

  ---------------------------------------------------------------------------

  woanware
  http://www.woanware.co.uk/

  



