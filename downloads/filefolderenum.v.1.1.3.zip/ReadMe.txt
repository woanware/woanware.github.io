

  filefolderenum

  Copyright (c) 2012 woanware
  Developed by Mark Woan (markwoan[at]gmail.com)

  ---------------------------------------------------------------------------

  A number of tools exist that can perform file/folder enumeration but they 
  generally suffer from false positives and cannot deal with custom 404 pages,
  this is where filefolderenum should create more consistent results.
  
  Features
  --------
  - Console
  - SSL support
  - Saves identified item to files
  - Cookie support
  - HTTP 1.0 and HTTP 1.1
  - Basic Auth/NTLM Auth
  - False postive and custom 404 detection
  
  Word Lists
  ----------
  It now uses a similar way to skipfish, which eliminates the need for multiple 
  input files. The word list files now use the following format:
  
  e:doc
  e:txt
  w:admin
  w:test
    
  Where the "e:" prefix denotes an extension and the "w:" prefix denotes a word.
  Have merged the skipfish "complete.wl" values with the existing lists, which 
  increases the dirs/files from 243 to 2008 and the extensions from 82 to 130. 
  These entries are in "Full.wl" There is a "Default.wl" which contains the old 
  values contained in "Directories.txt", "Files.txt" and "Extensions.txt". There
  is "Sharepoint.wl" which contains the values from:
  
  fuzzdb\Discovery\PredictableRes\Sharepoint.fuzz.txt"
  
  If a word list file is loaded and no extensions are identified, then the 
  directories list is cleared and all of the word list entries are deemed as 
  files, this emulates the "-i" input file mode added in v1.0.7

  Command Line Examples
  ---------------------
    
  -h "www.test.co.uk" -c "files" --customonly 
  
  The command line will perform the standard directory, file, extension checks 
  for the "/files" directory and below
  
  ---------------------------------------------------------------------------
  
  -h "www.test.co.uk" -c "files" -i "test.txt"
    
  The command line will perform checks using the "test.txt" input file for the
  "/files" directory and below. If the "test.txt" file consisted of the values 
  "a,b,c", then the requests would be for:
    
  /a
  /b
  /c
  /files/a
  /files/b
  /files/c
  
  ---------------------------------------------------------------------------
  
  -h "www.test.co.uk" -c "files" --customonly -i "test.txt"
  
  The command line will perform checks using the "test.txt" input file for the
  "/files" directory and below. If the "test.txt" file consisted of the values 
  "a,b,c", then the requests would be for:
  
  /files/a
  /files/b
  /files/c
   
  Disclaimer
  ----------
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.

  THIS APPLICATION IS ONLY TO BE USED ON WEBSITES/APPLICATIONS THAT EITHER YOU
  OWN OR HAVE EXPRESS WRITTEN PERMISSION TO TEST.

  BY USING THIS SOFTWARE YOU ARE AGREEING TO THE CONDITIONS AND TERMS EXPRESSED 
  ABOVE.

  System Requirements
  -------------------
  - Microsoft .NET Framework v4

  ---------------------------------------------------------------------------

  woanware
  http://www.woanware.co.uk/