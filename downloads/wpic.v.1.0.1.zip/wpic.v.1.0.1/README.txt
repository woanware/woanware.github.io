This folder contains the signed Release assemblies, their dependencies and XML documentation.
These are the assemblies and resources that are installed in GAC.

Below are the files expected in this folder:

    Awesomium.Core.dll
    Awesomium.Core.xml
    Awesomium.Windows.Controls.dll
    Awesomium.Windows.Controls.xml
    Awesomium.Windows.Controls.Design.dll
    Awesomium.Windows.Forms.dll
    Awesomium.Windows.Forms.xml
    Awesomium.dll
    AwesomiumProcess
    icudt42.dll
    en-US.dll
    README
