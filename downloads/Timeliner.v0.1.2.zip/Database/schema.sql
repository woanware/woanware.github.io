﻿CREATE USER tl WITH PASSWORD 'tl';
GRANT ALL PRIVILEGES ON DATABASE timeliner to tl;

-- Table (ENTRY)
CREATE TABLE entry
(
  id serial NOT NULL,
  projectid integer,
  ts timestamp without time zone,
  timezone character varying(50),
  macb character varying(10),
  source character varying(255),
  sourcetype character varying(255),
  type character varying(255),
  username text,
  host character varying(255),
  short text,
  description text,
  version character varying(10),
  filename text,
  inode character varying(20),
  notes text,
  format character varying(50),
  extra character varying(255),
  bookmarked boolean,
  comment text,
  mountpointprefix character varying(100),
  CONSTRAINT entry_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);

-- Table (PROJECT)
CREATE TABLE project
(
  id serial NOT NULL,
  name character varying(25),
  CONSTRAINT project_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);

-- Table (FILTER)
CREATE TABLE filter
(
  id serial NOT NULL,
  projectid integer,
  condition character varying(3),
  field character varying(16),
  operator character varying(8),
  value character varying(50),
  CONSTRAINT pk PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);

-- Filters
ALTER TABLE project OWNER TO tl;
ALTER TABLE entry OWNER TO tl;
ALTER TABLE filter OWNER TO tl;

-- Indexes
CREATE INDEX projectid_idx
  ON entry
  USING btree
  (projectid);

CREATE INDEX entry_projectid_ts_id_idx
  ON entry
  USING btree
  (projectid, ts, id);
  
CREATE INDEX name_idx
  ON project
  USING btree
  (name COLLATE pg_catalog."default");






