TRUNCATE TABLE  entry RESTART IDENTITY 
select * from entry where projectid=1 and (ts,id) > ('1900-01-01', 0) order by ts,id limit 1000