import json, pickle

with open("virustotal-search.pkl", "rb") as fpick:
    with open("virustotal-search.json", "w") as fjson:
        json.dump(pickle.load(fpick), fjson)