

  SqlServerDataExtractor

  Copyright (c) 2008 woanware
  Developed by Mark Woan (markwoan[at]hotmail.com)

  ---------------------------------------------------------------------------

  
  About
  -----
  Sometimes we need to drop a binary onto a box and extract the data. This 
  application allows you to specify the connection string and SQL statement.
  Once the SQL statement executed, the data is output to a file in the application
  directory, which is loaded into a browser control on the second tab. The 
  reason for using HTML to display the data, is that the application should 
  be flexible enough to handle alot of data...
  
  If you need help with SQL connection strings then check out:
  http://www.connectionstrings.com/
  
  I have given some example connection strings below.
 
  
  Connection Strings
  ------------------
  Data Source=IP;Initial Catalog=DB;User Id=USER;Password=PASS;
  Data Source=IP\INSTANCE;Initial Catalog=DB;User Id=USER;Password=PASS;
  Data Source=IP;Initial Catalog=DB;Integrated Security=SSPI;
  Data Source=IP\INSTANCE;Initial Catalog=DB;Integrated Security=SSPI;  
  

  SQL Statements
  --------------
  select @@version
  select user_name()
  select db_name()
  select * from sysusers
  select * from sysobjects where type = 'U' order by name
  select id from sysobjects where name = 'TABLE_NAME'
  select name from syscolumns where id = �123456789�
  
  
  Features
  --------
  - Nice little progress bar
  - Handles large volumes of data
  

  Disclaimer
  -------------------
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.

  BY USING THIS SOFTWARE YOU ARE AGREEING TO THE CONDITIONS AND TERMS EXPRESSED 
  ABOVE.


  System Requirements
  -------------------

  - Windows XP, Windows 2003 Server, Vista
  - Microsoft .NET Framework v2.0


  ---------------------------------------------------------------------------

  woanware
  http://www.woanware.co.uk

  



